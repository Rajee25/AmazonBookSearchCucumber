package AmazonTestRunner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature"
		,glue={"AmazonStepDefinition"}
		,plugin = {"pretty" ,"html:target/Reports" ,
                "json:target/Reports/cucumber.json" ,
                "junit:target/Reports/cucumber.xml"},
                monochrome = true
		)

public class AmazonBookTestRunner {

}