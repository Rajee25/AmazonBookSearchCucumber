package AmazonNavigationPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import AmazonNavigationPages.*;

public class AmazonHomepage {

   private static final String AMAZON_HOME_PAGE_URL = "https://www.amazon.co.uk/";

   private WebDriver driver;
   
 
   public AmazonHomepage(WebDriver driver) {

      this.driver = driver;

   }
// To open Amazon Home page
   public AmazonHomepage open() {

      driver.get(AMAZON_HOME_PAGE_URL);
      
      driver.manage().window().maximize();
      
      driver.manage().timeouts().implicitlyWait(30, TimeUnit.MILLISECONDS);
      
      return this;

   }
// To search for an item
   public AmazonHomepage searchItem(String searchkey) {
	   
	   driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchkey);
		
		 WebElement element = driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input"));

	     Actions action = new Actions(driver);

	     action.moveToElement(element).click().build().perform();

      return this;

   }

}



