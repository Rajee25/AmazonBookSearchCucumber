package AmazonNavigationPages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

public class AmazonCartPage {

	private static final By ADDED_ITEMS_BASKET = By.id("nav-cart");

	private static final By CHECK_OUT = By.xpath(".//*[@id='sc-buy-box-ptc-button']/span/input");

	private WebDriver driver;

	public AmazonCartPage(WebDriver driver) {

		this.driver = driver;

	}
// To click on the basket/cart
	public AmazonCartPage clickOnBasket() {

		driver.findElement(ADDED_ITEMS_BASKET).click();

		return this;
	}
// To click on the Proceed to checkout option
	public AmazonCartPage proceedToCheckout() {

		driver.findElement(CHECK_OUT).click();

		return this;

	}

}
