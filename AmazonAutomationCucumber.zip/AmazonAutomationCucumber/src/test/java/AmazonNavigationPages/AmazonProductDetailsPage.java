package AmazonNavigationPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonProductDetailsPage {

	private static final By ADD_TO_CART_BUTTON = By.id("add-to-cart-button");

	private WebDriver driver;

	public AmazonProductDetailsPage(WebDriver driver) {
	      this.driver = driver;
	   }
	
// To click to add the item in the cart	
	public AmazonProductDetailsPage addToCart() {
		
	      driver.findElement(ADD_TO_CART_BUTTON).click();
	      
	      return this;
	   }
	}


