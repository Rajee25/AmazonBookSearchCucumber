package AmazonNavigationPages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AmazonSearchResultsPage {

	private WebDriver driver;

	public AmazonSearchResultsPage(WebDriver driver) {

		this.driver = driver;

	}
// To get the count of items displayed on the current search page
	public AmazonSearchResultsPage getCountOfBooksDisplayed() {

		int result = driver.findElements(By.xpath(".//*[@id='atfResults']/ul[@id='s-results-list-atf']/li")).size();

		System.out.println("Number of books listed in current page is " + result);

		return this;

	}

// To click on the first item from the search list
	public void clickFirstSearchResult() {

		driver.findElement(By.xpath(".//*[@id='result_0']/div/div/div/div[2]/div[1]/div[1]/a/h2")).click();

	}

}
