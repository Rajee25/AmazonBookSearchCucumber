package AmazonStepDefinition;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import AmazonNavigationPages.*;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AmazonStepDefinition {

	private WebDriver driver;

	private AmazonHomepage homePage;

	// private SampleAmazonNavigation

	private AmazonSearchResultsPage searchResultsPage;

	private AmazonProductDetailsPage productDetailsPage;

	private AmazonCartPage cartPage;

	@Given("^Open www.amazon.co.uk$")
	public void Open_www_amazon_co_uk() throws Throwable {

		System.setProperty("webdriver.firefox.marionette",
				"C:\\Users\\RajeeAmit\\.m2\\repository\\org\\seleniumhq\\seleniumgeckodriver.exe");
		driver = new FirefoxDriver();
		homePage = new AmazonHomepage(driver).open();
	}

	@When("^Search for \"([^\"]*)\"$")
	public void Search_for(String Book) throws Throwable {

		homePage.searchItem(Book);

	}

	@Then("^Get the number of books \\(options\\) displayed on the current page$")
	public void Get_the_number_of_books_options_displayed_on_the_current_page() throws Throwable {

		searchResultsPage = new AmazonSearchResultsPage(driver).getCountOfBooksDisplayed();

	}

	@When("^Place order on the first book available$")
	public void Place_order_on_the_first_book_available() throws Throwable {

		searchResultsPage.clickFirstSearchResult();

		productDetailsPage = new AmazonProductDetailsPage(driver).addToCart();

	}

	@Then("^Validate that the basket has \"([^\"]*)\" item$")
	public void Validate_that_the_basket_has_item(String basketCount) throws Throwable {

		String ele = driver.findElement(By.id("nav-cart-count")).getText();

		assertEquals(ele, basketCount);

		System.out.println("Number of items in cart " + ele);

	}

	@Then("^Click on the basket$")
	public void Click_on_the_basket() throws Throwable {

		cartPage = new AmazonCartPage(driver).clickOnBasket();

	}

	@Then("^Click on “Proceed to Checkout”$")
	public void Click_on_Proceed_to_Checkout() throws Throwable {

		cartPage.proceedToCheckout();

	}

	@After
	public void embedScreenshot(Scenario scenario) {

		if (scenario.isFailed()) {
			scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
		}
		driver.close();
		driver.quit();
	}

}
